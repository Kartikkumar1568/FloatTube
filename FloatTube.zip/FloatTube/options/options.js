/**
 * FloatTube - Options Page Controller
 *
 * Handles:
 *  1. Settings toggles (auto-save on change)
 *  2. Custom Keyboard Shortcut Recorder
 *     - Click "Record" → row enters recording mode
 *     - Press any key combo → stored as pending change
 *     - Conflict detection (same combo used by two actions)
 *     - "Save Shortcuts" → persists to chrome.storage.sync
 *     - "Reset to Default" → restores DEFAULT_SHORTCUTS
 */

import { loadSettings, updateSetting, loadShortcuts, saveShortcuts, resetShortcuts } from '../shared/storage.js';
import { SHORTCUT_ACTIONS, DEFAULT_SHORTCUTS } from '../shared/constants.js';

// ─── Toast ────────────────────────────────────────────────────────────────────
const toastEl = document.getElementById('toast');
let toastTimer;

function showToast(msg, duration = 2000) {
  clearTimeout(toastTimer);
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), duration);
}

// ══════════════════════════════════════════════════════════════════════════════
//  SETTINGS TOGGLES
// ══════════════════════════════════════════════════════════════════════════════

const TOGGLE_IDS = [
  'autoPipOnTabSwitch',
  'autoPipOnMinimize',
  'rememberLastState',
  'keyboardShortcuts',
  'enableNotifications',
  'autoSkipAds',       // Auto-Skip Ads feature
];

async function renderSettings() {
  const settings = await loadSettings();
  for (const id of TOGGLE_IDS) {
    const el = document.getElementById(id);
    if (el) el.checked = Boolean(settings[id]);
  }
}

function wireToggles() {
  for (const id of TOGGLE_IDS) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.addEventListener('change', async () => {
      await updateSetting(id, el.checked);
      showToast('✓ Settings saved.');
    });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  KEYBOARD SHORTCUT RECORDER
// ══════════════════════════════════════════════════════════════════════════════

/** Currently pending shortcut changes (actionId → combo string). */
let pendingShortcuts = {};

/** Currently recording action ID, or null. */
let recordingActionId = null;

/** Reference to the active keydown listener so we can remove it. */
let recordingKeyListener = null;

// ─── Build Rows ───────────────────────────────────────────────────────────────

/**
 * Render all shortcut recorder rows into #shortcutRows.
 * @param {{ togglePip: string, muteVideo: string, playPause: string }} shortcuts
 */
function renderShortcutRows(shortcuts) {
  const container = document.getElementById('shortcutRows');
  container.innerHTML = '';

  for (const action of SHORTCUT_ACTIONS) {
    const combo   = pendingShortcuts[action.id] ?? shortcuts[action.id];
    const row     = buildRow(action, combo);
    container.appendChild(row);
  }
}

/**
 * Build a single recorder row element.
 * @param {{ id: string, label: string, icon: string }} action
 * @param {string} currentCombo
 * @returns {HTMLElement}
 */
function buildRow(action, currentCombo) {
  const row = document.createElement('div');
  row.className  = 'recorder-row';
  row.dataset.id = action.id;

  // Left: icon + label
  const info = document.createElement('div');
  info.className = 'recorder-info';

  const icon = document.createElement('div');
  icon.className   = 'recorder-icon';
  icon.textContent = action.icon;

  const label = document.createElement('div');
  label.className   = 'recorder-label';
  label.textContent = action.label;

  info.appendChild(icon);
  info.appendChild(label);

  // Middle: key badge display
  const badge = document.createElement('div');
  badge.className = 'key-badge';
  badge.dataset.badge = action.id;
  renderBadge(badge, currentCombo, false);

  // Right: Record button
  const btn = document.createElement('button');
  btn.className  = 'btn-record';
  btn.textContent = 'Record';
  btn.dataset.record = action.id;

  btn.addEventListener('click', () => startRecording(action.id));

  row.appendChild(info);
  row.appendChild(badge);
  row.appendChild(btn);

  return row;
}

/**
 * Render key combo text into a badge container.
 * Splits "Alt+Shift+P" into individual <kbd> elements.
 * @param {HTMLElement} badgeEl
 * @param {string}  combo
 * @param {boolean} isRecording
 */
function renderBadge(badgeEl, combo, isRecording) {
  badgeEl.innerHTML = '';

  if (isRecording) {
    const hint = document.createElement('span');
    hint.className   = 'recording-hint';
    hint.textContent = '● Press keys…';
    badgeEl.appendChild(hint);
    return;
  }

  const parts = combo.split('+');
  parts.forEach((part, i) => {
    const kbd = document.createElement('kbd');
    kbd.textContent = part;
    badgeEl.appendChild(kbd);
    if (i < parts.length - 1) {
      const plus = document.createElement('span');
      plus.textContent = '+';
      badgeEl.appendChild(plus);
    }
  });
}

// ─── Recording Logic ──────────────────────────────────────────────────────────

/**
 * Start recording a shortcut for the given action ID.
 * @param {string} actionId
 */
function startRecording(actionId) {
  // If already recording the same row — cancel
  if (recordingActionId === actionId) {
    stopRecording(false);
    return;
  }

  // If recording another row — cancel that one first
  if (recordingActionId) stopRecording(false);

  recordingActionId = actionId;

  // Update UI
  const row = document.querySelector(`.recorder-row[data-id="${actionId}"]`);
  const btn = document.querySelector(`.btn-record[data-record="${actionId}"]`);
  const badge = document.querySelector(`.key-badge[data-badge="${actionId}"]`);

  if (row)   row.classList.add('recording');
  if (btn)   { btn.textContent = 'Cancel'; btn.classList.add('active'); }
  if (badge) renderBadge(badge, '', true);

  // Listen for the key press
  recordingKeyListener = (e) => handleKeyCapture(e, actionId);
  window.addEventListener('keydown', recordingKeyListener, true);
}

/**
 * Stop recording mode.
 * @param {boolean} save - If true, keep the captured combo.
 */
function stopRecording(save = false) {
  if (recordingKeyListener) {
    window.removeEventListener('keydown', recordingKeyListener, true);
    recordingKeyListener = null;
  }

  const prevActionId = recordingActionId;
  recordingActionId  = null;

  if (!prevActionId) return;

  const row   = document.querySelector(`.recorder-row[data-id="${prevActionId}"]`);
  const btn   = document.querySelector(`.btn-record[data-record="${prevActionId}"]`);
  const badge = document.querySelector(`.key-badge[data-badge="${prevActionId}"]`);

  if (row) row.classList.remove('recording');
  if (btn) { btn.textContent = 'Record'; btn.classList.remove('active'); }

  // Restore badge to current pending or saved combo
  if (badge) {
    const combo = pendingShortcuts[prevActionId] ?? getCurrentSavedShortcut(prevActionId);
    renderBadge(badge, combo, false);
  }
}

/**
 * Handle a keydown event while in recording mode.
 * @param {KeyboardEvent} e
 * @param {string} actionId
 */
function handleKeyCapture(e, actionId) {
  e.preventDefault();
  e.stopPropagation();

  // Ignore pure modifier presses
  if (['Control', 'Alt', 'Shift', 'Meta', 'CapsLock', 'Tab'].includes(e.key)) return;

  // Escape = cancel recording
  if (e.key === 'Escape') {
    stopRecording(false);
    showToast('Recording cancelled.');
    return;
  }

  const combo = eventToShortcut(e);
  if (!combo) return;

  // Store pending change
  pendingShortcuts[actionId] = combo;

  // Update badge immediately
  const badge = document.querySelector(`.key-badge[data-badge="${actionId}"]`);
  if (badge) renderBadge(badge, combo, false);

  // Stop recording
  stopRecording(true);

  // Check for conflicts
  checkConflicts();

  // Enable Save button
  document.getElementById('saveShortcuts').disabled = false;

  showToast('✓ Shortcut captured: ' + combo);
}

/**
 * Highlight rows where two actions share the same combo.
 */
function checkConflicts() {
  const allCombos = {};

  for (const action of SHORTCUT_ACTIONS) {
    const combo = pendingShortcuts[action.id] ?? getCurrentSavedShortcut(action.id);
    allCombos[action.id] = combo;
  }

  for (const action of SHORTCUT_ACTIONS) {
    const row = document.querySelector(`.recorder-row[data-id="${action.id}"]`);
    if (!row) continue;

    const myCombo    = allCombos[action.id];
    const hasConflict = Object.entries(allCombos).some(
      ([id, combo]) => id !== action.id && combo === myCombo
    );

    row.classList.toggle('conflict', hasConflict);
  }
}

// ─── Saved Shortcuts Cache ────────────────────────────────────────────────────

let _savedShortcuts = { ...DEFAULT_SHORTCUTS };

function getCurrentSavedShortcut(actionId) {
  return _savedShortcuts[actionId] ?? DEFAULT_SHORTCUTS[actionId];
}

// ─── Save / Reset Buttons ─────────────────────────────────────────────────────

document.getElementById('saveShortcuts').addEventListener('click', async () => {
  // Merge pending into saved
  const merged = { ..._savedShortcuts, ...pendingShortcuts };

  // Conflict check — don't save if conflicts exist
  const combos = Object.values(merged);
  const unique  = new Set(combos);
  if (unique.size !== combos.length) {
    showToast('⚠ Two actions share the same shortcut. Fix conflicts first.', 3000);
    return;
  }

  await saveShortcuts(merged);
  _savedShortcuts = merged;
  pendingShortcuts = {};

  document.getElementById('saveShortcuts').disabled = true;
  checkConflicts();
  showToast('✅ Shortcuts saved! They work on YouTube immediately.');
});

document.getElementById('resetShortcuts').addEventListener('click', async () => {
  if (!confirm('Reset all shortcuts to their default values?')) return;

  await resetShortcuts();
  _savedShortcuts  = { ...DEFAULT_SHORTCUTS };
  pendingShortcuts = {};

  document.getElementById('saveShortcuts').disabled = true;
  renderShortcutRows(_savedShortcuts);
  checkConflicts();
  showToast('↩ Shortcuts reset to defaults.');
});

// ─── Key Event → Combo String ─────────────────────────────────────────────────

/**
 * Convert a KeyboardEvent to a normalized shortcut string.
 * e.g. "Alt+Shift+P", "Ctrl+Z"
 * @param {KeyboardEvent} e
 * @returns {string}
 */
function eventToShortcut(e) {
  const parts = [];
  if (e.ctrlKey)  parts.push('Ctrl');
  if (e.altKey)   parts.push('Alt');
  if (e.shiftKey) parts.push('Shift');
  if (e.metaKey)  parts.push('Meta');

  let key = e.key;
  if (key === ' ')           key = 'Space';
  else if (key.length === 1) key = key.toUpperCase();

  if (['Control', 'Alt', 'Shift', 'Meta'].includes(key)) return '';

  parts.push(key);
  return parts.join('+');
}

// ══════════════════════════════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════════════════════════════

(async () => {
  // Settings
  await renderSettings();
  wireToggles();

  // Shortcuts
  _savedShortcuts = await loadShortcuts();
  renderShortcutRows(_savedShortcuts);
  checkConflicts();
})();
