/**
 * FloatTube - Popup Controller
 *
 * Manages the popup UI lifecycle:
 *  1. On open → query background for current tab status
 *  2. Update UI to reflect status (ready / floating / not-youtube / error)
 *  3. Wire up buttons (PiP toggle, play/pause, mute, open YouTube)
 *  4. Show toast notifications inside the popup
 */

import { MSG, STATUS, SPEED_LEVELS } from '../shared/constants.js';
import { loadShortcuts, loadSettings, updateSetting } from '../shared/storage.js';


// ─── DOM References ───────────────────────────────────────────────────────────
const statusBadge    = document.getElementById('statusBadge');
const statusDot      = document.getElementById('statusDot');
const statusText     = document.getElementById('statusText');
const videoTitle     = document.getElementById('videoTitle');
const pipBtn         = document.getElementById('pipBtn');
const pipBtnText     = document.getElementById('pipBtnText');
const pipBtnIcon     = document.getElementById('pipBtnIcon');
const pipHint        = document.getElementById('pipHint');
const pipVisual      = document.getElementById('pipVisual');
const playPauseBtn   = document.getElementById('playPauseBtn');
const playPauseIcon  = document.getElementById('playPauseIcon');
const muteBtn        = document.getElementById('muteBtn');
const muteIcon       = document.getElementById('muteIcon');
const openYouTubeBtn = document.getElementById('openYouTubeBtn');
const openSettings   = document.getElementById('openSettings');
const videoControls  = document.getElementById('videoControls');
const toastEl        = document.getElementById('toast');
// Speed control
const speedButtons   = document.getElementById('speedButtons');
const speedCurrent   = document.getElementById('speedCurrent');
const speedPanel     = document.getElementById('speedPanel');
// Ad-Skip
const adSkipRow      = document.getElementById('adSkipRow');
const adSkipToggle   = document.getElementById('adSkipToggle');

// ─── Toast Utility ────────────────────────────────────────────────────────────
let toastTimer = null;

/**
 * Show a brief toast message inside the popup.
 * @param {string} msg
 * @param {number} [duration=2200]
 */
function showToast(msg, duration = 2200) {
  clearTimeout(toastTimer);
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), duration);
}

// ─── SVG Icon Strings ─────────────────────────────────────────────────────────
const ICONS = {
  // PiP "enter" — play arrow
  pipEnter: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5 3l14 9-14 9V3z" fill="currentColor"/>
  </svg>`,

  // PiP "restore" — minimize / restore
  pipRestore: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" stroke-width="2" fill="none"/>
    <path d="M8 12h8M12 8v8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
  </svg>`,

  // Play icon
  play: `<svg viewBox="0 0 24 24" fill="currentColor">
    <path d="M8 5v14l11-7z"/>
  </svg>`,

  // Pause icon
  pause: `<svg viewBox="0 0 24 24" fill="currentColor">
    <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
  </svg>`,

  // Volume on icon
  volumeOn: `<svg viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/>
  </svg>`,

  // Volume muted icon
  volumeOff: `<svg viewBox="0 0 24 24" fill="currentColor">
    <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
  </svg>`,
};

// ─── UI State Machine ─────────────────────────────────────────────────────────

/**
 * Render the popup UI based on the status response from the background.
 * @param {{status: string, isFloating?: boolean, isPaused?: boolean, isMuted?: boolean, videoTitle?: string}} state
 */
function renderStatus(state) {
  // Clear all status classes
  statusBadge.className = 'status-badge';
  pipVisual.classList.remove('floating', 'active');

  switch (state.status) {
    case STATUS.READY: {
      statusBadge.classList.add('ready');
      statusText.textContent   = 'Video Ready';
      pipBtn.disabled          = false;
      pipBtn.className         = 'pip-btn';
      pipBtnIcon.innerHTML     = ICONS.pipEnter;
      pipBtnText.textContent   = 'Start Floating';
      pipHint.textContent      = 'Click to launch Picture‑in‑Picture';
      pipVisual.classList.add('active');
      videoControls.style.opacity = '1';
      videoControls.style.pointerEvents = 'auto';

      // Reflect play/pause state
      if (state.isPaused) {
        playPauseIcon.innerHTML = ICONS.play;
        playPauseBtn.querySelector('span').textContent = 'Play';
        playPauseBtn.classList.remove('active');
      } else {
        playPauseIcon.innerHTML = ICONS.pause;
        playPauseBtn.querySelector('span').textContent = 'Pause';
      }

      // Reflect mute state
      if (state.isMuted) {
        muteIcon.innerHTML = ICONS.volumeOff;
        muteBtn.querySelector('span').textContent = 'Unmute';
        muteBtn.classList.add('active');
      } else {
        muteIcon.innerHTML = ICONS.volumeOn;
        muteBtn.querySelector('span').textContent = 'Mute';
        muteBtn.classList.remove('active');
      }

      videoTitle.textContent = trimTitle(state.videoTitle ?? '');
      break;
    }

    case STATUS.FLOATING: {
      statusBadge.classList.add('floating');
      statusText.textContent   = '● Floating Now';
      pipBtn.disabled          = false;
      pipBtn.className         = 'pip-btn restore';
      pipBtnIcon.innerHTML     = ICONS.pipRestore;
      pipBtnText.textContent   = 'Restore to Tab';
      pipHint.textContent      = 'Click to bring video back to the tab';
      pipVisual.classList.add('floating', 'active');
      videoControls.style.opacity = '1';
      videoControls.style.pointerEvents = 'auto';
      videoTitle.textContent   = trimTitle(state.videoTitle ?? '');
      break;
    }

    case STATUS.NOT_YOUTUBE: {
      statusBadge.classList.add('not-youtube');
      statusText.textContent   = 'Not YouTube';
      pipBtn.disabled          = true;
      pipBtn.className         = 'pip-btn';
      pipBtnIcon.innerHTML     = ICONS.pipEnter;
      pipBtnText.textContent   = 'Start Floating';
      pipHint.textContent      = 'Open a YouTube video first';
      videoTitle.textContent   = '';
      videoControls.style.opacity = '0.4';
      videoControls.style.pointerEvents = 'none';
      break;
    }

    case STATUS.NO_VIDEO: {
      statusBadge.classList.add('not-youtube');
      statusText.textContent   = 'No Video Found';
      pipBtn.disabled          = true;
      pipBtn.className         = 'pip-btn';
      pipBtnIcon.innerHTML     = ICONS.pipEnter;
      pipBtnText.textContent   = 'Start Floating';
      pipHint.textContent      = 'Play a video on YouTube first';
      videoTitle.textContent   = '';
      videoControls.style.opacity = '0.4';
      videoControls.style.pointerEvents = 'none';
      break;
    }

    case STATUS.NOT_SUPPORTED: {
      statusBadge.classList.add('error');
      statusText.textContent   = 'Not Supported';
      pipBtn.disabled          = true;
      pipBtnText.textContent   = 'Not Supported';
      pipHint.textContent      = 'Picture-in-Picture is not available in this browser';
      videoControls.style.opacity = '0.4';
      videoControls.style.pointerEvents = 'none';
      break;
    }

    default: {
      statusBadge.classList.add('error');
      statusText.textContent   = 'Error';
      pipBtn.disabled          = true;
      pipBtnText.textContent   = 'Start Floating';
      pipHint.textContent      = state.message ?? 'An unexpected error occurred';
      videoControls.style.opacity = '0.4';
      videoControls.style.pointerEvents = 'none';
    }
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Strip " - YouTube" suffix and trim long titles */
function trimTitle(title) {
  return title.replace(/ - YouTube$/, '').replace(/ - YouTube Music$/, '').slice(0, 55);
}

/**
 * Send a message to the background service worker and return the response.
 * @param {object} message
 * @returns {Promise<object>}
 */
async function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

// ─── Initialization ───────────────────────────────────────────────────────────

async function init() {
  statusText.textContent = 'Detecting...';

  // Load everything in parallel
  const [response, shortcuts, settings, speedRes] = await Promise.allSettled([
    sendMessage({ action: MSG.GET_STATUS }),
    loadShortcuts(),
    loadSettings(),
    sendMessage({ action: MSG.GET_SPEED }),
  ]);

  if (response.status === 'fulfilled') {
    renderStatus(response.value ?? { status: STATUS.ERROR });
  } else {
    renderStatus({ status: STATUS.ERROR, message: response.reason?.message });
  }

  // Shortcut strip
  if (shortcuts.status === 'fulfilled') renderShortcutsStrip(shortcuts.value);

  // Speed buttons
  buildSpeedButtons();
  const currentSpeed = speedRes.status === 'fulfilled' ? (speedRes.value?.speed ?? 1) : 1;
  updateSpeedUI(currentSpeed);

  // Ad-skip toggle
  if (settings.status === 'fulfilled') {
    const isEnabled = settings.value?.autoSkipAds !== false;
    adSkipToggle.checked = isEnabled;
    adSkipRow.classList.toggle('active', isEnabled);
  }
}

/**
 * Render the bottom shortcut strip with the user's current shortcut combos.
 * @param {{ togglePip: string, muteVideo: string, playPause: string }} sc
 */
function renderShortcutsStrip(sc) {
  const strip = document.querySelector('.shortcuts-strip');
  if (!strip) return;
  function badge(combo) {
    return combo.split('+').map(k => `<kbd>${k}</kbd>`).join('<span>+</span>');
  }
  strip.innerHTML = `
    <span class="shortcut-item">${badge(sc.togglePip)} Float</span>
    <span class="shortcut-item">${badge(sc.muteVideo)} Mute</span>
    <span class="shortcut-item">${badge(sc.playPause)} Play</span>
  `;
}

// ─── Speed Control Functions ──────────────────────────────────────────────────

/** Build speed buttons from SPEED_LEVELS and attach click handlers. */
function buildSpeedButtons() {
  speedButtons.innerHTML = '';
  for (const level of SPEED_LEVELS) {
    const btn = document.createElement('button');
    btn.className      = 'speed-btn';
    btn.dataset.speed  = level;
    btn.textContent    = level === 1 ? '1x' : level + 'x';
    btn.title          = `Set speed to ${level}x`;
    btn.addEventListener('click', async () => {
      const res = await sendMessage({ action: MSG.SET_SPEED, speed: level });
      if (res?.status === STATUS.READY || res?.speed !== undefined) {
        updateSpeedUI(res.speed ?? level);
        showToast(`Speed: ${res.speed ?? level}x`);
      } else if (res?.status === STATUS.NO_VIDEO) {
        showToast('No video found on YouTube tab.');
      }
    });
    speedButtons.appendChild(btn);
  }
}

/**
 * Highlight the active speed button and update the current-speed badge.
 * @param {number} speed
 */
function updateSpeedUI(speed) {
  if (speedCurrent) speedCurrent.textContent = speed + 'x';
  document.querySelectorAll('.speed-btn').forEach((btn) => {
    btn.classList.toggle('active', Number(btn.dataset.speed) === speed);
  });
}

// ─── Ad-Skip Toggle ───────────────────────────────────────────────────────────

adSkipToggle.addEventListener('change', async () => {
  const enabled = adSkipToggle.checked;
  await updateSetting('autoSkipAds', enabled);
  adSkipRow.classList.toggle('active', enabled);
  showToast(enabled ? '🚫 Auto-Skip Ads: ON' : '⏸ Auto-Skip Ads: OFF');
});



// Main PiP toggle
pipBtn.addEventListener('click', async () => {
  pipBtn.disabled = true;
  try {
    const response = await sendMessage({ action: MSG.TOGGLE_PIP });
    renderStatus(response ?? { status: STATUS.ERROR });

    if (response?.status === STATUS.FLOATING) {
      showToast('▶ Floating mode started!');
    } else if (response?.status === STATUS.READY) {
      showToast('↩ Video restored to tab.');
    } else if (response?.message) {
      showToast(response.message);
    }
  } catch (err) {
    showToast('Something went wrong.');
    renderStatus({ status: STATUS.ERROR, message: err.message });
  }
  pipBtn.disabled = false;
});

// Play / Pause
playPauseBtn.addEventListener('click', async () => {
  const response = await sendMessage({ action: MSG.PLAY_PAUSE });
  if (response?.status === STATUS.READY) {
    if (response.paused) {
      playPauseIcon.innerHTML = ICONS.play;
      playPauseBtn.querySelector('span').textContent = 'Play';
      showToast('⏸ Video paused.');
    } else {
      playPauseIcon.innerHTML = ICONS.pause;
      playPauseBtn.querySelector('span').textContent = 'Pause';
      showToast('▶ Video playing.');
    }
  }
});

// Mute / Unmute
muteBtn.addEventListener('click', async () => {
  const response = await sendMessage({ action: MSG.MUTE_VIDEO });
  if (response?.status === STATUS.READY) {
    if (response.muted) {
      muteIcon.innerHTML = ICONS.volumeOff;
      muteBtn.querySelector('span').textContent = 'Unmute';
      muteBtn.classList.add('active');
      showToast('🔇 Video muted.');
    } else {
      muteIcon.innerHTML = ICONS.volumeOn;
      muteBtn.querySelector('span').textContent = 'Mute';
      muteBtn.classList.remove('active');
      showToast('🔊 Video unmuted.');
    }
  }
});

// Open YouTube
openYouTubeBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://www.youtube.com' });
  window.close();
});

// Open Settings
openSettings.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

// ─── Boot ─────────────────────────────────────────────────────────────────────
init();
