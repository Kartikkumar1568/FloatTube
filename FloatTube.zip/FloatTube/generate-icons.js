/**
 * FloatTube - Icon Generator Script
 * Run with Node.js to generate PNG icons from SVG
 * Usage: node generate-icons.js
 * 
 * This script creates placeholder icons if you don't have
 * an image editor. For production, replace with high-quality PNGs.
 */

const fs   = require('fs');
const path = require('path');

// ─── SVG source (same design as popup logo) ───────────────────────────────────
function buildSVG(size) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"
     xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ff416c"/>
      <stop offset="100%" stop-color="#ff4b2b"/>
    </linearGradient>
  </defs>

  <!-- Background rounded rect -->
  <rect width="${size}" height="${size}" rx="${size * 0.2}"
        fill="url(#bg)"/>

  <!-- Main screen -->
  <rect x="${size*0.1}" y="${size*0.22}" width="${size*0.8}" height="${size*0.56}"
        rx="${size*0.08}" fill="rgba(0,0,0,0.45)"/>

  <!-- Play triangle -->
  <polygon
    points="${size*0.38},${size*0.35} ${size*0.38},${size*0.65} ${size*0.65},${size*0.50}"
    fill="white"/>

  <!-- PiP corner indicator -->
  <rect x="${size*0.6}" y="${size*0.56}" width="${size*0.3}" height="${size*0.2}"
        rx="${size*0.04}" fill="rgba(255,255,255,0.9)"/>
  <polygon
    points="${size*0.65},${size*0.60} ${size*0.65},${size*0.72} ${size*0.84},${size*0.66}"
    fill="#ff416c"/>
</svg>`;
}

const sizes  = [16, 32, 48, 128];
const outDir = path.join(__dirname, 'icons');

if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

for (const size of sizes) {
  const svgContent = buildSVG(size);
  // Write SVG (used as fallback / source)
  fs.writeFileSync(path.join(outDir, `icon${size}.svg`), svgContent);
  console.log(`✓ Generated icon${size}.svg`);
}

console.log('\nSVG icons created in /icons directory.');
console.log('For PNG icons: open each .svg in a browser, screenshot at the correct size,');
console.log('or use a tool like Inkscape / sharp to convert SVG → PNG.\n');
