# 🎬 FloatTube — YouTube Floating Player Chrome Extension

<div align="center">

![FloatTube Icon](icons/icon128.png)

**Convert any YouTube video into a floating Picture-in-Picture window with one click.**

[![Manifest V3](https://img.shields.io/badge/Manifest-V3-blue?style=flat-square)](https://developer.chrome.com/docs/extensions/mv3/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange?style=flat-square)](#)

</div>

---

## ✨ Features

| Feature | Description |
|---|---|
| 🖥️ **One-Click Floating** | Launch Picture-in-Picture with a single click on the extension icon |
| 🎵 **Music YouTube Support** | Works on `music.youtube.com` too |
| ⌨️ **Keyboard Shortcuts** | `Alt+Shift+P`, `Alt+Shift+M`, `Alt+Shift+Space` |
| ⚙️ **Smart Settings** | Auto-PiP on tab switch or minimize |
| 🔔 **Notifications** | Desktop notifications for key actions |
| 🔒 **100% Private** | No data collected, no analytics, no tracking |
| ⚡ **Lightweight** | No external libraries, runs fully offline |

---

## 📁 Folder Structure

```
FloatTube/
├── manifest.json              ← Extension manifest (MV3)
├── README.md                  ← This file
├── privacy-policy.md          ← Privacy policy
├── LICENSE                    ← MIT License
│
├── icons/                     ← Extension icons (PNG)
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
│
├── popup/                     ← Extension popup UI
│   ├── popup.html
│   ├── popup.css
│   └── popup.js
│
├── background/                ← Service worker
│   └── background.js
│
├── content/                   ← Content script (injected into YouTube)
│   └── content.js
│
├── options/                   ← Settings page
│   ├── options.html
│   ├── options.css
│   └── options.js
│
└── shared/                    ← Shared modules
    ├── constants.js
    └── storage.js
```

---

## 🚀 Installation Guide

### Load Unpacked (Developer Mode)

1. **Download** this project folder to your computer
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable **Developer Mode** (toggle in top-right corner)
4. Click **"Load unpacked"**
5. Select the `FloatTube` folder
6. The extension icon appears in your toolbar ✅

### Pinning the Extension

1. Click the puzzle-piece icon 🧩 in Chrome's toolbar
2. Find **FloatTube** in the list
3. Click the pin icon 📌 to always show it

---

## 🎮 How to Use

### Basic Usage

1. Open any YouTube video at `youtube.com/watch?v=...`
2. Click the **FloatTube** extension icon in your toolbar
3. Click the big **"Start Floating"** button
4. The video opens in a floating Picture-in-Picture window!
5. Click **"Restore to Tab"** to bring it back

### Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Alt + Shift + P` | Toggle floating mode on/off |
| `Alt + Shift + M` | Mute / unmute the video |
| `Alt + Shift + Space` | Play / pause the video |

> **Note:** To customize shortcuts, visit `chrome://extensions/shortcuts`

### Settings

Click the ⚙️ gear icon in the popup, or right-click the extension → **Options**:

| Setting | Description |
|---|---|
| Auto Float on Tab Switch | Auto-PiP when you switch away from YouTube |
| Auto Float on Minimize | Auto-PiP when Chrome is minimized |
| Remember Last State | Restore PiP on next visit |
| Keyboard Shortcuts | Enable/disable shortcut keys |
| Show Notifications | Enable/disable Chrome notifications |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Chrome Extension                       │
│                                                           │
│  ┌──────────┐    messages    ┌──────────────────────────┐ │
│  │  Popup   │◄──────────────►│  Background Service      │ │
│  │  (UI)    │                │  Worker                  │ │
│  └──────────┘                │                          │ │
│                              │  • Command handling       │ │
│  ┌──────────┐    messages    │  • Tab management         │ │
│  │ Options  │◄──────────────►│  • Auto-PiP logic         │ │
│  │  (UI)    │                │  • Notifications          │ │
│  └──────────┘                └────────────┬─────────────┘ │
│                                           │               │
│                              scripting   │               │
│                              API         │               │
│                                          ▼               │
│                         ┌────────────────────────────┐   │
│                         │    Content Script          │   │
│                         │   (injected into YouTube)  │   │
│                         │                            │   │
│                         │  • Video element detection │   │
│                         │  • PiP API calls           │   │
│                         │  • Mute / Play / Pause     │   │
│                         │  • Status reporting        │   │
│                         └────────────────────────────┘   │
│                                                           │
│  ┌────────────────────────────────────────────────────┐  │
│  │                  Shared Modules                    │  │
│  │        constants.js  ·  storage.js                 │  │
│  └────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## 🔐 Permissions Explained

| Permission | Why it's needed |
|---|---|
| `activeTab` | Read the current tab's URL to detect YouTube |
| `scripting` | Inject the content script into YouTube tabs |
| `storage` | Save user settings (sync) and last state (local) |
| `notifications` | Show desktop alerts |
| `tabs` | Find YouTube tabs when the active tab isn't YouTube |

---

## 🛡️ Security & Privacy

- ✅ Zero external network requests
- ✅ No data collection or analytics
- ✅ No third-party libraries
- ✅ All logic runs 100% offline on your machine
- ✅ Permissions are minimal and justified

---

## 🤝 Contributing

1. Fork this repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m "Add my feature"`
4. Push to the branch: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

<div align="center">
  Made with ❤️ · FloatTube v1.0.0
</div>
