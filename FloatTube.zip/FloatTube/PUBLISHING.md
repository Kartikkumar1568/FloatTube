# Chrome Web Store Publishing Guide — FloatTube

## Prerequisites

1. A Google Developer account at [chrome.google.com/webstore/devconsole](https://chrome.google.com/webstore/devconsole)
2. One-time $5 USD developer registration fee

---

## Step 1: Package the Extension

Create a ZIP file of the entire `FloatTube` folder:

```powershell
# PowerShell (Windows)
Compress-Archive -Path "d:\chrome extensions\FloatTube\*" -DestinationPath "FloatTube_v1.0.0.zip"
```

> ⚠️ Do NOT include: `node_modules/`, `.git/`, `icon-generator.html`, `make-*.js`, `generate-icons.js`

---

## Step 2: Chrome Web Store Developer Dashboard

1. Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole/)
2. Click **"New Item"**
3. Upload `FloatTube_v1.0.0.zip`

---

## Step 3: Store Listing Information

### Basic Info

| Field | Value |
|---|---|
| **Name** | FloatTube - YouTube Floating Player |
| **Short Description** | Float any YouTube video into Picture-in-Picture with one click! Multitask while watching. |
| **Category** | Productivity |
| **Language** | English |

### Long Description (use this)

```
🎬 FloatTube — YouTube Floating Player

Float any YouTube video into a Picture-in-Picture window with just one click! 
Keep watching while you code, study, design, or work.

✨ FEATURES:
• One-click Picture-in-Picture for any YouTube video
• Works on youtube.com, music.youtube.com
• Play/Pause and Mute controls inside the popup
• Keyboard shortcuts: Alt+Shift+P (float), Alt+Shift+M (mute), Alt+Shift+Space (play/pause)
• Auto-float when you switch tabs or minimize Chrome
• Desktop notifications for key actions
• Beautiful dark glassmorphism interface

🔒 PRIVACY:
• Zero data collection
• No analytics or tracking
• No external network requests
• Works completely offline

🚀 HOW TO USE:
1. Open a YouTube video
2. Click the FloatTube icon in your toolbar
3. Click "Start Floating"
4. Multitask freely!
```

---

## Step 4: Screenshots

Prepare at least 3 screenshots (1280x800 or 640x400 px):

1. **Popup — Ready State**: Extension popup showing a YouTube video detected
2. **Popup — Floating State**: Popup showing video currently in PiP mode
3. **Settings Page**: The options/settings page
4. **In Action**: YouTube video playing while PiP window is visible

---

## Step 5: Privacy Practices

In the "Privacy Practices" section:

- ✅ "This extension does not collect or use user data"
- ✅ Justify all permissions with the reasons from `README.md`
- Link to: `privacy-policy.md` (host it on GitHub Pages or similar)

---

## Step 6: Submit for Review

- Review typically takes **1-3 business days** for a new extension
- Once approved, your extension will be live on the Chrome Web Store

---

## Tips for Approval

- Ensure all permissions are justified in the privacy section
- Make sure the extension works exactly as described
- Avoid using terms like "best", "most powerful" in the description
- Include clear screenshots that show the extension in use

---

## Updating the Extension

1. Increment the `version` in `manifest.json` (e.g., `1.0.1`)
2. Re-create the ZIP file
3. Go to your Developer Dashboard → your extension → **"Upload new package"**
