const fs   = require('fs');
const path = require('path');

const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });

function buildSVG(size) {
  const r  = Math.round(size * 0.18);
  const p  = (frac) => Math.round(size * frac);
  return [
    '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '" xmlns="http://www.w3.org/2000/svg">',
    '<defs>',
    '<linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">',
    '<stop offset="0%" stop-color="#ff416c"/>',
    '<stop offset="100%" stop-color="#ff4b2b"/>',
    '</linearGradient>',
    '</defs>',
    '<rect width="' + size + '" height="' + size + '" rx="' + r + '" fill="url(#bg)"/>',
    '<rect x="' + p(0.10) + '" y="' + p(0.22) + '" width="' + p(0.80) + '" height="' + p(0.56) + '" rx="' + p(0.07) + '" fill="rgba(0,0,0,0.5)"/>',
    '<polygon points="' + p(0.37) + ',' + p(0.35) + ' ' + p(0.37) + ',' + p(0.65) + ' ' + p(0.66) + ',' + p(0.50) + '" fill="white"/>',
    '<rect x="' + p(0.58) + '" y="' + p(0.55) + '" width="' + p(0.32) + '" height="' + p(0.22) + '" rx="' + p(0.04) + '" fill="rgba(255,255,255,0.92)"/>',
    '<polygon points="' + p(0.63) + ',' + p(0.60) + ' ' + p(0.63) + ',' + p(0.72) + ' ' + p(0.83) + ',' + p(0.66) + '" fill="#ff416c"/>',
    '</svg>'
  ].join('\n');
}

[16, 32, 48, 128].forEach(function(size) {
  fs.writeFileSync(path.join(iconsDir, 'icon' + size + '.svg'), buildSVG(size));
  console.log('Created icon' + size + '.svg');
});

console.log('All SVG icons created in /icons/');
