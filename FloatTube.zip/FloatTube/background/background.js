/**
 * FloatTube - Background Service Worker (Manifest V3)
 *
 * Responsibilities:
 *  • Listen for keyboard shortcut commands
 *  • Listen for messages from popup and content scripts
 *  • Handle auto-PiP on tab-switch / minimize (when enabled)
 *  • Send Chrome notifications
 *  • Route toggle/mute/play-pause actions to the correct content script
 */

import { MSG, STATUS, NOTIF_ID, YT_PATTERNS, EXT_NAME } from '../shared/constants.js';
import { loadSettings, saveLastState, clearLastState, loadLastState } from '../shared/storage.js';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Returns true if the given URL matches any known YouTube pattern.
 * @param {string} url
 * @returns {boolean}
 */
function isYouTubeUrl(url) {
  if (!url) return false;
  return YT_PATTERNS.some((pattern) => url.includes(pattern));
}

/**
 * Find the best YouTube tab to work with.
 * Preference: active tab → most recently active YT tab.
 * @returns {Promise<chrome.tabs.Tab|null>}
 */
async function findYouTubeTab() {
  // 1. Check the currently active tab first
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && isYouTubeUrl(activeTab.url)) return activeTab;

  // 2. Fall back to any YT tab in any window
  const ytTabs = await chrome.tabs.query({ url: ['*://*.youtube.com/*', '*://*.music.youtube.com/*'] });
  if (ytTabs.length === 0) return null;

  // Sort by lastAccessed desc so we get the most recent one
  ytTabs.sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
  return ytTabs[0];
}

/**
 * Send a message to a tab's content script and await the response.
 * Returns null instead of throwing if the tab has no content script.
 * @param {number} tabId
 * @param {object} message
 * @returns {Promise<object|null>}
 */
async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch {
    return null;
  }
}

// ─── Notifications ────────────────────────────────────────────────────────────

/**
 * Show a Chrome notification if the user has them enabled.
 * @param {string} id      - Notification ID (from NOTIF_ID)
 * @param {string} title
 * @param {string} message
 */
async function showNotification(id, title, message) {
  const settings = await loadSettings();
  if (!settings.enableNotifications) return;

  chrome.notifications.create(id, {
    type:    'basic',
    iconUrl: chrome.runtime.getURL('icons/icon48.png'),
    title,
    message,
    priority: 1,
  });
}

// ─── Core PiP Toggle ─────────────────────────────────────────────────────────

/**
 * Toggle Picture-in-Picture on the best available YouTube tab.
 * @returns {Promise<{status: string, message: string}>}
 */
async function togglePiP() {
  const tab = await findYouTubeTab();

  if (!tab) {
    await showNotification(NOTIF_ID.NOT_FOUND, EXT_NAME, 'YouTube tab not found. Open a YouTube video first.');
    return { status: STATUS.NOT_YOUTUBE, message: 'No YouTube tab found.' };
  }

  // Inject the content script first (handles cases where it wasn't injected yet)
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files:  ['content/content.js'],
    });
  } catch {
    // Already injected — safe to ignore
  }

  const response = await sendToTab(tab.id, { action: MSG.TOGGLE_PIP });

  if (!response) {
    return { status: STATUS.ERROR, message: 'Could not communicate with page.' };
  }

  // Handle notification based on new state
  if (response.status === STATUS.FLOATING) {
    await saveLastState({ tabId: tab.id, url: tab.url });
    await showNotification(NOTIF_ID.STARTED, EXT_NAME, '▶ Floating mode started.');
  } else if (response.status === STATUS.READY) {
    await clearLastState();
    await showNotification(NOTIF_ID.RESTORED, EXT_NAME, '↩ Video restored to tab.');
  }

  return response;
}

/**
 * Send mute command to the best YouTube tab.
 * @returns {Promise<object|null>}
 */
async function muteVideo() {
  const tab = await findYouTubeTab();
  if (!tab) return null;
  return sendToTab(tab.id, { action: MSG.MUTE_VIDEO });
}

/**
 * Send play/pause command to the best YouTube tab.
 * @returns {Promise<object|null>}
 */
async function playPause() {
  const tab = await findYouTubeTab();
  if (!tab) return null;
  return sendToTab(tab.id, { action: MSG.PLAY_PAUSE });
}

// ─── Keyboard Commands ────────────────────────────────────────────────────────

chrome.commands.onCommand.addListener(async (command) => {
  const settings = await loadSettings();
  if (!settings.keyboardShortcuts) return;

  switch (command) {
    case 'toggle-pip':  await togglePiP();  break;
    case 'mute-video':  await muteVideo();   break;
    case 'play-pause':  await playPause();   break;
  }
});

// ─── Message Router ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  // Must return true to keep the channel open for async response
  (async () => {
    switch (message.action) {
      case MSG.TOGGLE_PIP:
        sendResponse(await togglePiP());
        break;

      case MSG.MUTE_VIDEO:
        sendResponse(await muteVideo());
        break;

      case MSG.PLAY_PAUSE:
        sendResponse(await playPause());
        break;

      case MSG.GET_STATUS: {
        const tab = await findYouTubeTab();
        if (!tab) {
          sendResponse({ status: STATUS.NOT_YOUTUBE });
          break;
        }
        const res = await sendToTab(tab.id, { action: MSG.GET_STATUS });
        sendResponse(res ?? { status: STATUS.ERROR });
        break;
      }

      default:
        sendResponse({ status: STATUS.ERROR, message: 'Unknown action.' });
    }
  })();
  return true; // keep port open
});

// ─── Auto-PiP: Tab Switch ─────────────────────────────────────────────────────

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const settings = await loadSettings();
  if (!settings.autoPipOnTabSwitch) return;

  // If the user switched AWAY from a YouTube tab, auto-enter PiP
  // We detect this by checking the previously focused tab (stored in last state)
  const lastState = await loadLastState();
  if (!lastState) return;

  const prevTabId = lastState.tabId;
  if (activeInfo.tabId === prevTabId) return; // switched back to YT tab

  // Check that the previous YT tab still exists
  try {
    const prevTab = await chrome.tabs.get(prevTabId);
    if (prevTab && isYouTubeUrl(prevTab.url)) {
      const res = await sendToTab(prevTabId, { action: MSG.GET_STATUS });
      // Only auto-PiP if not already floating
      if (res && res.status === STATUS.READY) {
        await sendToTab(prevTabId, { action: MSG.TOGGLE_PIP });
        await showNotification(NOTIF_ID.STARTED, EXT_NAME, '▶ Auto floating mode activated.');
      }
    }
  } catch {
    // Tab no longer exists
    await clearLastState();
  }
});

// ─── Auto-PiP: Window Minimize ────────────────────────────────────────────────

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  const settings = await loadSettings();
  if (!settings.autoPipOnMinimize) return;
  if (windowId !== chrome.windows.WINDOW_ID_NONE) return; // Not minimized

  const tab = await findYouTubeTab();
  if (!tab) return;

  const res = await sendToTab(tab.id, { action: MSG.GET_STATUS });
  if (res && res.status === STATUS.READY) {
    await togglePiP();
  }
});

// ─── Install / Update Handler ─────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Open a welcome/onboarding tab on first install
    chrome.tabs.create({ url: 'https://youtube.com' });
  }
});
