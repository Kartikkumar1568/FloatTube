// FloatTube - Pure Node.js PNG Icon Creator
// Creates valid minimal PNG files without any dependencies
// Uses raw PNG binary format (zlib deflate)

const fs   = require('fs');
const path = require('path');
const zlib = require('zlib');

// ─── PNG helpers ─────────────────────────────────────────────────────────────

function uint32BE(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n >>> 0, 0);
  return b;
}

function crc32(buf) {
  let crc = 0xffffffff;
  const table = makeCRCTable();
  for (let i = 0; i < buf.length; i++) {
    crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

let _crcTable;
function makeCRCTable() {
  if (_crcTable) return _crcTable;
  _crcTable = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    _crcTable[n] = c;
  }
  return _crcTable;
}

function pngChunk(type, data) {
  const typeBytes = Buffer.from(type, 'ascii');
  const lenBuf    = uint32BE(data.length);
  const crcBuf    = uint32BE(crc32(Buffer.concat([typeBytes, data])));
  return Buffer.concat([lenBuf, typeBytes, data, crcBuf]);
}

/**
 * Create a PNG buffer from an RGBA pixel array.
 * @param {number} width
 * @param {number} height
 * @param {Uint8Array} pixels - RGBA bytes, row-major
 * @returns {Buffer}
 */
function createPNG(width, height, pixels) {
  // PNG signature
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width,  0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8]  = 8;  // bit depth
  ihdr[9]  = 6;  // RGBA color type
  ihdr[10] = 0;  // compression
  ihdr[11] = 0;  // filter
  ihdr[12] = 0;  // interlace

  // Raw image data with filter bytes
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0; // None filter
    for (let x = 0; x < width; x++) {
      const srcOff = (y * width + x) * 4;
      const dstOff = y * (width * 4 + 1) + 1 + x * 4;
      raw[dstOff]     = pixels[srcOff];
      raw[dstOff + 1] = pixels[srcOff + 1];
      raw[dstOff + 2] = pixels[srcOff + 2];
      raw[dstOff + 3] = pixels[srcOff + 3];
    }
  }

  const compressed = zlib.deflateSync(raw, { level: 9 });

  return Buffer.concat([
    sig,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', compressed),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

// ─── Icon drawing ─────────────────────────────────────────────────────────────

/**
 * Draw the FloatTube icon into a flat RGBA Uint8Array.
 * @param {number} size
 * @returns {Uint8Array}
 */
function drawIcon(size) {
  const pixels = new Uint8Array(size * size * 4); // all transparent

  // Helpers
  function setPixel(x, y, r, g, b, a) {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const off = (y * size + x) * 4;
    // Alpha compositing over existing
    const srcA = a / 255;
    const dstA = pixels[off + 3] / 255;
    const outA = srcA + dstA * (1 - srcA);
    if (outA === 0) return;
    pixels[off]     = Math.round((r * srcA + pixels[off]     * dstA * (1 - srcA)) / outA);
    pixels[off + 1] = Math.round((g * srcA + pixels[off + 1] * dstA * (1 - srcA)) / outA);
    pixels[off + 2] = Math.round((b * srcA + pixels[off + 2] * dstA * (1 - srcA)) / outA);
    pixels[off + 3] = Math.round(outA * 255);
  }

  // Gradient background colour at (x,y) — linear from top-left to bottom-right
  function gradColor(x, y) {
    const t = (x + y) / (size * 2);
    return {
      r: Math.round(0xff * (1 - t) + 0xff * t),
      g: Math.round(0x41 * (1 - t) + 0x4b * t),
      b: Math.round(0x6c * (1 - t) + 0x2b * t),
    };
  }

  const cornerR = Math.round(size * 0.18);

  // Fill rounded-rect background
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (!insideRoundRect(x, y, 0, 0, size, size, cornerR)) continue;
      const { r, g, b } = gradColor(x, y);
      setPixel(x, y, r, g, b, 255);
    }
  }

  // Dark screen rect
  const sx = Math.round(size * 0.10), sy = Math.round(size * 0.22);
  const sw = Math.round(size * 0.80), sh = Math.round(size * 0.56);
  const sr = Math.round(size * 0.07);
  for (let y = sy; y < sy + sh; y++) {
    for (let x = sx; x < sx + sw; x++) {
      if (!insideRoundRect(x, y, sx, sy, sw, sh, sr)) continue;
      setPixel(x, y, 0, 0, 0, 128);
    }
  }

  // White play triangle
  const tx1 = Math.round(size * 0.37), ty1 = Math.round(size * 0.35);
  const tx2 = Math.round(size * 0.37), ty2 = Math.round(size * 0.65);
  const tx3 = Math.round(size * 0.66), ty3 = Math.round(size * 0.50);
  for (let y = ty1; y <= ty2; y++) {
    for (let x = tx1; x <= tx3; x++) {
      if (inTriangle(x, y, tx1, ty1, tx2, ty2, tx3, ty3)) {
        setPixel(x, y, 255, 255, 255, 255);
      }
    }
  }

  // PiP corner white box
  const px = Math.round(size * 0.58), py = Math.round(size * 0.55);
  const pw = Math.round(size * 0.32), ph = Math.round(size * 0.22);
  const pr = Math.round(size * 0.04);
  for (let y = py; y < py + ph; y++) {
    for (let x = px; x < px + pw; x++) {
      if (!insideRoundRect(x, y, px, py, pw, ph, pr)) continue;
      setPixel(x, y, 255, 255, 255, 235);
    }
  }

  // Mini red play triangle inside PiP box
  const mx1 = Math.round(size * 0.63), my1 = Math.round(size * 0.60);
  const mx2 = Math.round(size * 0.63), my2 = Math.round(size * 0.72);
  const mx3 = Math.round(size * 0.83), my3 = Math.round(size * 0.66);
  for (let y = my1; y <= my2; y++) {
    for (let x = mx1; x <= mx3; x++) {
      if (inTriangle(x, y, mx1, my1, mx2, my2, mx3, my3)) {
        setPixel(x, y, 255, 65, 108, 255);
      }
    }
  }

  return pixels;
}

// ─── Geometry helpers ─────────────────────────────────────────────────────────

function insideRoundRect(x, y, rx, ry, rw, rh, r) {
  const lx = rx + r, rx2 = rx + rw - r;
  const ty = ry + r, by  = ry + rh - r;
  if (x >= lx && x <= rx2) return y >= ry && y < ry + rh;
  if (y >= ty && y <= by)  return x >= rx && x < rx + rw;
  if (x < lx && y < ty) return dist2(x, y, lx, ty) <= r * r;
  if (x > rx2 && y < ty) return dist2(x, y, rx2, ty) <= r * r;
  if (x < lx && y > by)  return dist2(x, y, lx, by) <= r * r;
  if (x > rx2 && y > by) return dist2(x, y, rx2, by) <= r * r;
  return false;
}

function dist2(x1, y1, x2, y2) {
  return (x1 - x2) ** 2 + (y1 - y2) ** 2;
}

function sign(px, py, ax, ay, bx, by) {
  return (px - bx) * (ay - by) - (ax - bx) * (py - by);
}

function inTriangle(px, py, ax, ay, bx, by, cx, cy) {
  const d1 = sign(px, py, ax, ay, bx, by);
  const d2 = sign(px, py, bx, by, cx, cy);
  const d3 = sign(px, py, cx, cy, ax, ay);
  const hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
  const hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);
  return !(hasNeg && hasPos);
}

// ─── Main ─────────────────────────────────────────────────────────────────────

const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });

[16, 32, 48, 128].forEach(function(size) {
  const pixels = drawIcon(size);
  const png    = createPNG(size, size, pixels);
  const outPath = path.join(iconsDir, 'icon' + size + '.png');
  fs.writeFileSync(outPath, png);
  console.log('✓ Created ' + outPath + ' (' + png.length + ' bytes)');
});

console.log('\nAll PNG icons created successfully!');
