/**
 * FloatTube - Storage Utility
 * Async/await wrappers around chrome.storage APIs.
 */

import { STORAGE_KEYS, DEFAULT_SETTINGS } from './constants.js';

// ─── Settings ─────────────────────────────────────────────────────────────────

/** Load persisted settings, falling back to defaults for missing keys. */
export async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(STORAGE_KEYS.SETTINGS, (result) => {
      const saved = result[STORAGE_KEYS.SETTINGS] ?? {};
      resolve({ ...DEFAULT_SETTINGS, ...saved });
    });
  });
}

/** Save full settings object to sync storage. */
export async function saveSettings(settings) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [STORAGE_KEYS.SETTINGS]: settings }, resolve);
  });
}

/** Update a single setting key without overwriting others. */
export async function updateSetting(key, value) {
  const current = await loadSettings();
  const updated  = { ...current, [key]: value };
  await saveSettings(updated);
  return updated;
}

// ─── Last State ───────────────────────────────────────────────────────────────

/** Persist last PiP state. */
export async function saveLastState(state) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [STORAGE_KEYS.LAST_STATE]: state }, resolve);
  });
}

/** Load last PiP state. */
export async function loadLastState() {
  return new Promise((resolve) => {
    chrome.storage.local.get(STORAGE_KEYS.LAST_STATE, (result) => {
      resolve(result[STORAGE_KEYS.LAST_STATE] ?? null);
    });
  });
}

/** Clear last PiP state. */
export async function clearLastState() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(STORAGE_KEYS.LAST_STATE, resolve);
  });
}

// ─── Custom Shortcuts ─────────────────────────────────────────────────────────
import { SHORTCUT_STORAGE_KEY, DEFAULT_SHORTCUTS } from './constants.js';

/**
 * Load custom shortcuts, falling back to defaults for any missing actions.
 * @returns {Promise<{togglePip: string, muteVideo: string, playPause: string}>}
 */
export async function loadShortcuts() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(SHORTCUT_STORAGE_KEY, (result) => {
      const saved = result[SHORTCUT_STORAGE_KEY] ?? {};
      resolve({ ...DEFAULT_SHORTCUTS, ...saved });
    });
  });
}

/**
 * Persist the full shortcuts object.
 * @param {{togglePip: string, muteVideo: string, playPause: string}} shortcuts
 * @returns {Promise<void>}
 */
export async function saveShortcuts(shortcuts) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [SHORTCUT_STORAGE_KEY]: shortcuts }, resolve);
  });
}

/**
 * Reset all custom shortcuts to their factory defaults.
 * @returns {Promise<void>}
 */
export async function resetShortcuts() {
  return saveShortcuts({ ...DEFAULT_SHORTCUTS });
}
