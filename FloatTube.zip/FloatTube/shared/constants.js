/**
 * FloatTube - Shared Constants
 * Central place for all constant values used across the extension.
 * Importing from here prevents "magic string" bugs.
 */

// ─── Message Action Types ────────────────────────────────────────────────────
export const MSG = Object.freeze({
  TOGGLE_PIP:      'TOGGLE_PIP',
  MUTE_VIDEO:      'MUTE_VIDEO',
  PLAY_PAUSE:      'PLAY_PAUSE',
  GET_STATUS:      'GET_STATUS',
  SETTINGS_UPDATE: 'SETTINGS_UPDATE',
  SET_SPEED:       'SET_SPEED',    // Set video playback rate
  GET_SPEED:       'GET_SPEED',    // Get current playback rate
});

// ─── Tab Status Codes ────────────────────────────────────────────────────────
export const STATUS = Object.freeze({
  READY:         'READY',         // YouTube tab found, video is playing/paused
  FLOATING:      'FLOATING',      // Currently in PiP mode
  NOT_YOUTUBE:   'NOT_YOUTUBE',   // Active tab is not YouTube
  NO_VIDEO:      'NO_VIDEO',      // YouTube tab but no video element found
  NOT_SUPPORTED: 'NOT_SUPPORTED', // Browser does not support PiP
  ERROR:         'ERROR',         // Generic / unexpected error
});

// ─── Storage Keys ────────────────────────────────────────────────────────────
export const STORAGE_KEYS = Object.freeze({
  SETTINGS:   'floattube_settings',
  LAST_STATE: 'floattube_last_state',
});

// ─── Default Settings ────────────────────────────────────────────────────────
export const DEFAULT_SETTINGS = Object.freeze({
  autoPipOnTabSwitch:  false,
  autoPipOnMinimize:   false,
  rememberLastState:   true,
  keyboardShortcuts:   true,
  enableNotifications: true,
  autoSkipAds:         true,   // Auto-skip YouTube ads
  defaultSpeed:        1,      // Default playback speed (1 = normal)
});

// ─── Playback Speed Levels ───────────────────────────────────────────────────
/** Available speed options shown in the popup speed control. */
export const SPEED_LEVELS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

// ─── Custom Keyboard Shortcuts ────────────────────────────────────────────────
// These are PAGE-LEVEL shortcuts (work when YouTube tab is focused).
// Keys are action IDs; values are shortcut strings like "Alt+Shift+P".

export const SHORTCUT_STORAGE_KEY = 'floattube_shortcuts';

/** Default shortcut key combos (mirrors the manifest.json commands). */
export const DEFAULT_SHORTCUTS = Object.freeze({
  togglePip: 'Alt+Shift+P',
  muteVideo:  'Alt+Shift+M',
  playPause:  'Alt+Shift+Space',
});

/**
 * Metadata for each customizable action.
 * Used to render rows in the options page.
 */
export const SHORTCUT_ACTIONS = [
  { id: 'togglePip', label: 'Toggle Floating Mode',  icon: '▶' },
  { id: 'muteVideo',  label: 'Mute / Unmute Video',   icon: '🔇' },
  { id: 'playPause',  label: 'Play / Pause Video',    icon: '⏸' },
];

// ─── YouTube URL Patterns ────────────────────────────────────────────────────
export const YT_PATTERNS = [
  'youtube.com/watch',
  'music.youtube.com',
  'youtube.com/embed',
];

// ─── Notification IDs ────────────────────────────────────────────────────────
export const NOTIF_ID = Object.freeze({
  STARTED:   'floattube_started',
  RESTORED:  'floattube_restored',
  NOT_FOUND: 'floattube_not_found',
  ERROR:     'floattube_error',
});

export const EXT_NAME = 'FloatTube';
