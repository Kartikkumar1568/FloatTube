# Privacy Policy for FloatTube

**Last Updated:** July 2026

---

## Overview

FloatTube is a Chrome Extension that enables Picture-in-Picture (floating) mode for YouTube videos.

**FloatTube does not collect, store, transmit, or share any personal data.**

---

## Data Collection

FloatTube collects **no data** of any kind. Specifically:

- ❌ No personal information
- ❌ No browsing history
- ❌ No video watch history
- ❌ No usage statistics or analytics
- ❌ No crash reports sent to any server
- ❌ No identifiers (no cookies, no device IDs)

---

## Local Storage Only

FloatTube stores only your **extension settings** (such as whether keyboard shortcuts are enabled) locally on your device using Chrome's `storage.sync` API. This data:

- Never leaves your device except to sync across your own Chrome profile via Google's infrastructure
- Contains only on/off preferences — no personal information
- Can be cleared at any time by removing the extension

---

## Network Requests

FloatTube makes **zero network requests**. All functionality runs completely offline.

---

## Third-Party Services

FloatTube does not use:

- Analytics services (Google Analytics, Mixpanel, etc.)
- Advertising networks
- Crash reporting services
- Remote configuration services
- Content Delivery Networks (CDNs)

---

## Permissions Justification

| Permission | Justification |
|---|---|
| `activeTab` | Detect if the current tab is a YouTube page |
| `scripting` | Inject the content script to control video playback |
| `storage` | Save your extension settings locally |
| `notifications` | Show optional desktop alerts |
| `tabs` | Find YouTube tabs when switching tabs |

---

## Changes to This Policy

If this privacy policy is updated, the new version will be published with the extension update.

---

## Contact

If you have questions about this privacy policy, please open an issue on the project's GitHub repository.

---

*FloatTube is open-source software released under the MIT License.*
