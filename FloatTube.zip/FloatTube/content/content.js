/**
 * FloatTube - Content Script
 *
 * Injected into YouTube tabs. Responsibilities:
 *  • Find the <video> element on the page
 *  • Toggle Picture-in-Picture via the browser PiP API
 *  • Mute / unmute the video
 *  • Play / pause the video
 *  • Set / get playback speed                  ← NEW
 *  • Auto-skip YouTube ads (MutationObserver)  ← NEW
 *  • Custom keyboard shortcut listener
 *  • Report current status back to the background
 */

(() => {
  // ─── Guard: prevent running twice ───────────────────────────────────────────
  if (window.__floatTubeInjected) return;
  window.__floatTubeInjected = true;

  // ─── Inlined constants (content scripts cannot use ES module imports) ────────
  const MSG = Object.freeze({
    TOGGLE_PIP:  'TOGGLE_PIP',
    MUTE_VIDEO:  'MUTE_VIDEO',
    PLAY_PAUSE:  'PLAY_PAUSE',
    GET_STATUS:  'GET_STATUS',
    SET_SPEED:   'SET_SPEED',
    GET_SPEED:   'GET_SPEED',
  });

  const STATUS = Object.freeze({
    READY:         'READY',
    FLOATING:      'FLOATING',
    NOT_YOUTUBE:   'NOT_YOUTUBE',
    NO_VIDEO:      'NO_VIDEO',
    NOT_SUPPORTED: 'NOT_SUPPORTED',
    ERROR:         'ERROR',
  });

  const SETTINGS_KEY  = 'floattube_settings';
  const SHORTCUTS_KEY = 'floattube_shortcuts';
  const DEFAULT_SHORTCUTS = { togglePip: 'Alt+Shift+P', muteVideo: 'Alt+Shift+M', playPause: 'Alt+Shift+Space' };

  // ═══════════════════════════════════════════════════════════════════════════
  //  VIDEO DISCOVERY
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Find the primary video element on the page.
   * @returns {HTMLVideoElement|null}
   */
  function findVideo() {
    const ytPlayer = document.querySelector('video.html5-main-video');
    if (ytPlayer) return ytPlayer;

    const allVideos = Array.from(document.querySelectorAll('video'));
    if (allVideos.length === 0) return null;
    allVideos.sort((a, b) => (b.duration ?? 0) - (a.duration ?? 0));
    return allVideos[0];
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  CORE VIDEO ACTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  /** Toggle Picture-in-Picture mode. */
  async function togglePiP() {
    if (!document.pictureInPictureEnabled) {
      return { status: STATUS.NOT_SUPPORTED, message: 'PiP not supported in this browser.' };
    }
    const video = findVideo();
    if (!video) return { status: STATUS.NO_VIDEO, message: 'No video element found.' };

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        return { status: STATUS.READY, message: 'Exited Picture-in-Picture.' };
      }
      if (video.readyState < 2) {
        return { status: STATUS.ERROR, message: 'Video not ready yet. Try again in a moment.' };
      }
      await video.requestPictureInPicture();
      return { status: STATUS.FLOATING, message: 'Entered Picture-in-Picture.' };
    } catch (err) {
      return { status: STATUS.ERROR, message: err.message ?? 'Unknown PiP error.' };
    }
  }

  /** Toggle mute on the primary video. */
  function muteVideo() {
    const video = findVideo();
    if (!video) return { status: STATUS.NO_VIDEO, message: 'No video found.' };
    video.muted = !video.muted;
    return { status: STATUS.READY, muted: video.muted };
  }

  /** Toggle play / pause on the primary video. */
  async function playPause() {
    const video = findVideo();
    if (!video) return { status: STATUS.NO_VIDEO, message: 'No video found.' };
    try {
      if (video.paused) { await video.play(); } else { video.pause(); }
      return { status: STATUS.READY, paused: video.paused };
    } catch (err) {
      return { status: STATUS.ERROR, message: err.message };
    }
  }

  /**
   * Set the playback speed of the primary video.
   * @param {number} rate - e.g. 0.5, 1, 1.5, 2
   */
  function setSpeed(rate) {
    const video = findVideo();
    if (!video) return { status: STATUS.NO_VIDEO, message: 'No video found.' };

    // Clamp to safe range
    const clamped = Math.max(0.1, Math.min(16, Number(rate)));
    video.playbackRate = clamped;

    // Also update YouTube's internal rate (keeps YT UI in sync)
    try {
      const player = document.querySelector('#movie_player') ?? document.querySelector('.html5-video-player');
      if (player?.setPlaybackRate) player.setPlaybackRate(clamped);
    } catch { /* non-critical */ }

    return { status: STATUS.READY, speed: video.playbackRate };
  }

  /** Get current playback speed. */
  function getSpeed() {
    const video = findVideo();
    return {
      status: video ? STATUS.READY : STATUS.NO_VIDEO,
      speed:  video?.playbackRate ?? 1,
    };
  }

  /** Return full current status of video / PiP. */
  function getStatus() {
    if (!document.pictureInPictureEnabled) return { status: STATUS.NOT_SUPPORTED };
    const video = findVideo();
    if (!video) return { status: STATUS.NO_VIDEO };

    const isFloating = document.pictureInPictureElement === video;
    return {
      status:     isFloating ? STATUS.FLOATING : STATUS.READY,
      isFloating,
      isPaused:   video.paused,
      isMuted:    video.muted,
      speed:      video.playbackRate,
      videoTitle: document.title ?? '',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  AUTO-SKIP ADS  ← NEW
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * CSS selectors for the YouTube skip-ad button.
   * YouTube updates its UI frequently so we try several variants.
   */
  const SKIP_BTN_SELECTORS = [
    '.ytp-skip-ad-button',
    '.ytp-ad-skip-button',
    '.ytp-ad-skip-button-modern',
    '.ytp-ad-skip-button-container button',
    'button.ytp-ad-skip-ad-button',
    '[class*="skip-ad"]',
  ];

  /**
   * Attempt to skip the currently playing ad.
   * Returns true if an action was taken.
   * @returns {boolean}
   */
  function trySkipAd() {
    // 1. Click the skip button if it's visible
    for (const sel of SKIP_BTN_SELECTORS) {
      const btn = document.querySelector(sel);
      if (btn && btn.offsetParent !== null) {
        btn.click();
        console.log('[FloatTube] Ad skipped via button:', sel);
        return true;
      }
    }

    // 2. Non-skippable ad? Jump video to end so it moves on
    const player = document.querySelector('.html5-video-player');
    const isAdShowing = player?.classList.contains('ad-showing');
    if (isAdShowing) {
      const video = findVideo();
      if (video && isFinite(video.duration) && video.duration > 0) {
        video.currentTime = video.duration;
        console.log('[FloatTube] Non-skippable ad fast-forwarded to end.');
        return true;
      }
    }

    return false;
  }

  /**
   * Interval handle used while an ad is playing.
   * We retry every 300 ms because the skip button only appears
   * after 5 seconds — we need to click it as soon as it shows up.
   */
  let adSkipInterval = null;

  /** Start the ad-skip retry loop. */
  function startAdSkipLoop() {
    if (adSkipInterval) return; // already running
    adSkipInterval = setInterval(() => {
      const player  = document.querySelector('.html5-video-player');
      const adShowing = player?.classList.contains('ad-showing');

      if (!adShowing) {
        // Ad is gone — clean up
        clearInterval(adSkipInterval);
        adSkipInterval = null;
        return;
      }

      // Check that user hasn't disabled the setting
      chrome.storage.sync.get(SETTINGS_KEY, (result) => {
        const settings = result[SETTINGS_KEY] ?? {};
        if (settings.autoSkipAds !== false) trySkipAd();
      });
    }, 300);
  }

  /**
   * MutationObserver watching the YouTube player's class list.
   * Fires when the `ad-showing` class is added (= ad starts).
   */
  const adObserver = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== 'attributes' || mutation.attributeName !== 'class') continue;

      const el = /** @type {Element} */ (mutation.target);
      if (!el.classList.contains('ad-showing')) continue;

      // Ad just started — check setting then act
      chrome.storage.sync.get(SETTINGS_KEY, (result) => {
        const settings = result[SETTINGS_KEY] ?? {};
        if (settings.autoSkipAds === false) return;

        // Immediate attempt + retry loop
        trySkipAd();
        startAdSkipLoop();
      });
      break;
    }
  });

  /**
   * Attach the ad observer to the video player element.
   * If the player isn't in the DOM yet, wait for it.
   */
  function initAdObserver() {
    const player = document.querySelector('.html5-video-player');
    if (player) {
      adObserver.observe(player, { attributes: true, attributeFilter: ['class'] });
      // Handle case where page loads mid-ad
      if (player.classList.contains('ad-showing')) {
        chrome.storage.sync.get(SETTINGS_KEY, (result) => {
          const settings = result[SETTINGS_KEY] ?? {};
          if (settings.autoSkipAds !== false) { trySkipAd(); startAdSkipLoop(); }
        });
      }
    } else {
      // Player not yet rendered — wait
      const waitObserver = new MutationObserver(() => {
        const p = document.querySelector('.html5-video-player');
        if (p) {
          waitObserver.disconnect();
          adObserver.observe(p, { attributes: true, attributeFilter: ['class'] });
        }
      });
      waitObserver.observe(document.body, { childList: true, subtree: true });
    }
  }

  initAdObserver();

  // ═══════════════════════════════════════════════════════════════════════════
  //  MESSAGE LISTENER
  // ═══════════════════════════════════════════════════════════════════════════

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    (async () => {
      switch (message.action) {
        case MSG.TOGGLE_PIP:  sendResponse(await togglePiP());          break;
        case MSG.MUTE_VIDEO:  sendResponse(muteVideo());                break;
        case MSG.PLAY_PAUSE:  sendResponse(await playPause());          break;
        case MSG.GET_STATUS:  sendResponse(getStatus());                break;
        case MSG.SET_SPEED:   sendResponse(setSpeed(message.speed));    break;
        case MSG.GET_SPEED:   sendResponse(getSpeed());                 break;
        default:
          sendResponse({ status: STATUS.ERROR, message: 'Unknown action.' });
      }
    })();
    return true;
  });

  // ═══════════════════════════════════════════════════════════════════════════
  //  CUSTOM KEYBOARD SHORTCUTS
  // ═══════════════════════════════════════════════════════════════════════════

  let customShortcuts = { ...DEFAULT_SHORTCUTS };

  function loadShortcutsFromStorage() {
    chrome.storage.sync.get(SHORTCUTS_KEY, (result) => {
      const saved = result[SHORTCUTS_KEY];
      customShortcuts = (saved && typeof saved === 'object')
        ? { ...DEFAULT_SHORTCUTS, ...saved }
        : { ...DEFAULT_SHORTCUTS };
    });
  }

  loadShortcutsFromStorage();

  // Live-sync when options page saves new shortcuts
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes[SHORTCUTS_KEY]) {
      customShortcuts = { ...DEFAULT_SHORTCUTS, ...(changes[SHORTCUTS_KEY].newValue ?? {}) };
    }
  });

  function eventToShortcut(e) {
    const parts = [];
    if (e.ctrlKey)  parts.push('Ctrl');
    if (e.altKey)   parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (e.metaKey)  parts.push('Meta');
    let key = e.key;
    if (key === ' ')           key = 'Space';
    else if (key.length === 1) key = key.toUpperCase();
    if (['Control', 'Alt', 'Shift', 'Meta'].includes(key)) return '';
    parts.push(key);
    return parts.join('+');
  }

  document.addEventListener('keydown', async (e) => {
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || document.activeElement?.isContentEditable) return;

    const settingsResult = await new Promise((res) => chrome.storage.sync.get(SETTINGS_KEY, res));
    const settings = settingsResult[SETTINGS_KEY] ?? {};
    if (settings.keyboardShortcuts === false) return;

    const combo = eventToShortcut(e);
    if (!combo) return;

    let action = null;
    if (combo === customShortcuts.togglePip) action = MSG.TOGGLE_PIP;
    else if (combo === customShortcuts.muteVideo)  action = MSG.MUTE_VIDEO;
    else if (combo === customShortcuts.playPause)  action = MSG.PLAY_PAUSE;

    if (!action) return;
    e.preventDefault();
    e.stopPropagation();

    switch (action) {
      case MSG.TOGGLE_PIP: await togglePiP(); break;
      case MSG.MUTE_VIDEO: muteVideo();        break;
      case MSG.PLAY_PAUSE: await playPause();  break;
    }
  }, true);

  // ═══════════════════════════════════════════════════════════════════════════
  //  PiP LIFECYCLE
  // ═══════════════════════════════════════════════════════════════════════════

  document.addEventListener('leavepictureinpicture', () => {
    chrome.runtime.sendMessage({ action: 'PIP_ENDED' }).catch(() => {});
  });

})();
